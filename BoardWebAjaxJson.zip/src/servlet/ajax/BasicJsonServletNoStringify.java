package servlet.ajax;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import board.dto.UserDto;

@WebServlet("/BasicJsonServletNoStringify")
public class BasicJsonServletNoStringify extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		process(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		process(request, response);
	}

	protected void process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String userSeq = request.getParameter("userSeq");
		String userName = request.getParameter("userName");
		String userEmail = request.getParameter("userEmail");
//		Gson gson = new Gson();
//		UserDto userDto = gson.fromJson(json, UserDto.class);
		
		UserDto userDto = new UserDto();
		userDto.setUserSeq(Integer.parseInt(userSeq));
		userDto.setUserName(userName);
		userDto.setUserEmail(userEmail);
		response.setContentType("text/html; charset=utf-8");
		response.getWriter().write("success");
		System.out.println("BasicJsonServlet - " + userDto.getUserSeq() + " " + userDto.getUserName() + " " + userDto.getUserEmail());
	}
}
